
package Vista;

import Modelo.Categoria;
import Modelo.CategoriaDAO;
import Modelo.Compra;
import Modelo.CompraDAO;
import Modelo.DetalleVenta;
import Modelo.Productos;
import Modelo.ProductosDAO;
import Modelo.Proovedores;
import Modelo.ProovedoresDAO;
import Modelo.VentaDao;
import Modelo.Ventas;
import Modelo.login;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Sistema extends javax.swing.JFrame {

    //Inicializacion 
    Categoria cat = new Categoria();
    CategoriaDAO catd = new CategoriaDAO();
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel tmp = new DefaultTableModel();
    Productos pro = new Productos();
    ProductosDAO prod = new ProductosDAO();
    Ventas v = new Ventas();
    VentaDao vdao = new VentaDao();
    DetalleVenta Dv = new DetalleVenta();
    Proovedores prov = new Proovedores();
    ProovedoresDAO provdao = new ProovedoresDAO();
    Compra c = new Compra();
    CompraDAO cdao = new CompraDAO();
    Registro open = new Registro();
    
    int item;
    int totalpagar = 0;
    
    public Sistema() {
        initComponents();
    }
    
    public Sistema(login priv){
        initComponents();
        this.setLocationRelativeTo(null); //centra pagina
        prod.LlenarCategoria(cmbcategorias);
        if(priv.getRol().equals("Vendedor")){
            btnproductos.setEnabled(false);
            btnproovedor.setEnabled(false);
            btnconfiguracion.setEnabled(false);
            btncategoria.setEnabled(false);
            lblvendedor.setText(priv.getNombre());

        }else{
            lblvendedor.setText(priv.getNombre());
        }
        
    }

    //Funciones
    public void ListarCategoria(){
        LimpiarTable();
        List<Categoria> ListarCat =  catd.ListarCategoria();
        modelo = (DefaultTableModel) tblcategoria.getModel(); 
        Object[] ob = new Object[2];
        for (int i = 0; i < ListarCat.size(); i++){ //Lista la tabla Categoria
            ob[0] = ListarCat.get(i).getCategoria();
            ob[1] = ListarCat.get(i).getNombre();
            modelo.addRow(ob);
        }
        tblcategoria.setModel(modelo);
    }
    
    public void ListarProductos(){
        List<Productos> ListarPro =  prod.ListarProductos();
        modelo = (DefaultTableModel) tblproductos.getModel(); 
        Object[] ob = new Object[5];
        for (int i = 0; i < ListarPro.size(); i++){ //Lista la tabla Categoria
            ob[0] = ListarPro.get(i).getCod_articulo();
            ob[1] = ListarPro.get(i).getCod_categoria();
            ob[2] = ListarPro.get(i).getNombre_articulo();
            ob[3] = ListarPro.get(i).getPrecio_venta();
            ob[4] = ListarPro.get(i).getStock_actual();
            modelo.addRow(ob);
        }
        tblproductos.setModel(modelo);
    }
    
    public void ListarProovedores(){
        List<Proovedores> ListarProv =  provdao.ListarProovedores();
        modelo = (DefaultTableModel) tableproovedores.getModel(); 
        Object[] ob = new Object[5];
        for (int i = 0; i < ListarProv.size(); i++){ //Lista la tabla Categoria
            ob[0] = ListarProv.get(i).getRut_proovedor();
            ob[1] = ListarProv.get(i).getTelefono();
            ob[2] = ListarProv.get(i).getNombre();
            ob[3] = ListarProv.get(i).getEmpresa();
            modelo.addRow(ob);
        }
        tableproovedores.setModel(modelo);
    }
    
    public void ListarVentas(){
        List<Ventas> ListarVenta =  vdao.ListarVentas();
        modelo = (DefaultTableModel) tableregistroventa.getModel(); 
        Object[] ob = new Object[5];
        for (int i = 0; i < ListarVenta.size(); i++){ //Lista la tabla Categoria
            ob[0] = ListarVenta.get(i).getId_venta();
            ob[1] = ListarVenta.get(i).getValor_total();
            ob[2] = ListarVenta.get(i).getFecha();
            modelo.addRow(ob);
        }
        tableregistroventa.setModel(modelo);
    }

    public void LimpiarTable() {
    if (modelo != null) {
        modelo.setRowCount(0); // Limpia todas las filas del modelo
    }
    
}
                
    private void TotalPagar(){
        totalpagar = 0;
        int numFila = tableventa.getRowCount();
        for(int i = 0; i < numFila; i++){
            int cal = Integer.parseInt(String.valueOf(tableventa.getModel().getValueAt(i, 4)));
            totalpagar = totalpagar + cal;
        }
        lbltotal.setText(String.valueOf(totalpagar));
    }
    
    private void Vuelto() {
        try {
            int total = 0; // Inicializa el total a 0

        // Recorre las filas de la tabla para sumar los valores de la columna 4
            int numFila = tableventa.getRowCount();
            for (int i = 0; i < numFila; i++) {
               Object value = tableventa.getModel().getValueAt(i, 4); // Obtén el valor de la celda
                if (value != null) {
                    total += Integer.parseInt(value.toString()); // Suma los valores
                }
            }

        // Verifica si el campo de efectivo está vacío
            String efectivoTexto = txtefectivo.getText().trim();
                if (efectivoTexto.isEmpty()) {
                    return;
         }

        // Convierte el efectivo a entero
           int efectivo = Integer.parseInt(efectivoTexto);

        // Verifica si el efectivo es menor al total
            if (efectivo < total) {
               return;
            }

        // Calcula el vuelto
            int vuelto = efectivo - total;

        // Actualiza el label del vuelto
            lblvuelto.setText(String.valueOf(vuelto));

        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
    
    private void LimpiarVenta(){
        txtcodigoventa.setText("");
        txtdescripcionventa.setText("");
        txtcantidadventa.setText("");
        txtstockventa.setText("");
        txtprecioventa.setText("");
    }
    
    private void RegistrarVenta(){
        Date fecha = new Date();
        int monto = totalpagar;
        v.setValor_total(monto);
        v.setFecha(fecha);
        vdao.RegistrarVenta(v);
    }
    
    private void RegistrarCompra(){
        Date fecha = new Date();
        int monto = totalpagar;
        c.setId_compra(monto);
        c.setFecha(fecha);
        vdao.RegistrarVenta(v);
    }
    
    private void RegistrarDetalleVenta(){
        int id = vdao.IdVenta();
        for(int i = 0; i < tableventa.getRowCount(); i++){
            int cod = Integer.parseInt(tableventa.getValueAt(i, 0).toString());
            int cant = Integer.parseInt(tableventa.getValueAt(i, 2).toString());
            int precio = Integer.parseInt(tableventa.getValueAt(i, 3).toString());
            Dv.setId_venta(id);
            Dv.setCod_articulo(cod);
            Dv.setCantidad(cant);
            Dv.setPrecio_unitario_venta(precio);
            vdao.RegistrarDetalleVenta(Dv);
        }
    }
            
    private void ActualizarStock(){
        for(int i = 0; i < tableventa.getRowCount(); i++){
            String cod = tableventa.getValueAt(i,0).toString();
            int cant = Integer.parseInt(tableventa.getValueAt(i,2).toString());
            pro = prod.BuscarPro(cod);
            int StockActual = pro.getStock_actual() - cant;
            vdao.ActualizarStock(StockActual, cod);
        }
    }
    
    private void LimpiarTableVenta(){
        tmp = (DefaultTableModel) tableventa.getModel();
        int fila = tableventa.getRowCount();
        for(int i = 0; i < fila; i++){
            tmp.removeRow(0);
        }
    }
    
    
    private void pdf(){
        try{
            String medio = cmbmodopago.getSelectedItem().toString();
            int id = vdao.IdVenta();
            FileOutputStream archivo;
            File file = new File("src/pdf/venta_"+id+".pdf");
            archivo = new FileOutputStream(file);
            Document doc = new Document();
            PdfWriter.getInstance(doc, archivo);
            
            doc.open();
            Image img = Image.getInstance("src/img/images.jpg");
            
            Paragraph fecha = new Paragraph();
            Font negrita = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLUE);
            fecha.add(Chunk.NEWLINE);
            Date date = new Date();
            fecha.add("Boleta:" + id + "\n" + "Fecha: "+ new SimpleDateFormat("dd-MM-yyyy").format(date)+"\n\n");
            
            PdfPTable Encabezado = new PdfPTable(4);
            Encabezado.setWidthPercentage(100);
            Encabezado.getDefaultCell().setBorder(0);
            float[] ColumnaEncabezado = new float[]{20f, 40f , 70f, 40f};
            Encabezado.setWidths(ColumnaEncabezado);
            Encabezado.setHorizontalAlignment(Element.ALIGN_LEFT);
            
            Encabezado.addCell(img);
            
            
            String titulo = "Donde Leito";
            String titulo2 = "Sientete como en casa";
            String titulo3 = "Ubicados en pepitotepenua 554";
            String titulo4 = "Abrimos todos los dias";
            
            Encabezado.addCell("");
            Encabezado.addCell(titulo + "\n" + titulo2 + "\n" + titulo3 + "\n" + titulo4);
            Encabezado.addCell(fecha);
            doc.add(Encabezado);
            
            Paragraph cli = new Paragraph();
            cli.add(Chunk.NEWLINE);
            cli.add("Datos Boleta"+"\n\n");
            doc.add(cli);
            
            //Productos
            
            PdfPTable tablepro = new PdfPTable(4);
            tablepro.setWidthPercentage(100);
            tablepro.getDefaultCell().setBorder(0);
            float[] Columnapro = new float[]{10f, 50f , 15f, 20f};
            tablepro.setWidths(Columnapro);
            tablepro.setHorizontalAlignment(Element.ALIGN_LEFT);
            PdfPCell pro1 = new PdfPCell(new Phrase("Cant.", negrita));
            PdfPCell pro2 = new PdfPCell(new Phrase("Descripcion", negrita));
            PdfPCell pro3 = new PdfPCell(new Phrase("Precio U.", negrita));
            PdfPCell pro4 = new PdfPCell(new Phrase("Precio T.", negrita));
            pro1.setBorder(0);
            pro2.setBorder(0);
            pro3.setBorder(0);
            pro4.setBorder(0);
            pro1.setBackgroundColor(BaseColor.DARK_GRAY);
            pro2.setBackgroundColor(BaseColor.DARK_GRAY);
            pro3.setBackgroundColor(BaseColor.DARK_GRAY);
            pro4.setBackgroundColor(BaseColor.DARK_GRAY);
            tablepro.addCell(pro1);
            tablepro.addCell(pro2);
            tablepro.addCell(pro3);
            tablepro.addCell(pro4);
            for(int i = 0; i < tableventa.getRowCount(); i++){
                String producto = tableventa.getValueAt(i, 1).toString();
                String cantidad = tableventa.getValueAt(i, 2).toString();
                String precio = tableventa.getValueAt(i, 3).toString();
                String total = tableventa.getValueAt(i, 4).toString();
                tablepro.addCell(cantidad);
                tablepro.addCell(producto);
                tablepro.addCell(precio);
                tablepro.addCell(total);
                
            }
            doc.add(tablepro);
            
            Paragraph info = new Paragraph();
            info.add(Chunk.NEWLINE);
            info.add("Total a pagar: $"+ lbltotal.getText() + "\n");
            info.setAlignment(Element.ALIGN_RIGHT);
            doc.add(info);
            
            Paragraph MedioPago = new Paragraph();
            MedioPago.add(Chunk.NEWLINE);
            MedioPago.add("Medio de pago: "+ medio + "\n");
            MedioPago.setAlignment(Element.ALIGN_RIGHT);
            doc.add(MedioPago);
            
            Paragraph mensaje = new Paragraph();
            mensaje.add(Chunk.NEWLINE);
            mensaje.add("Gracias por su compra");
            mensaje.setAlignment(Element.ALIGN_RIGHT);
            doc.add(mensaje);
                       
            doc.close();            
            Desktop.getDesktop().open(file);
            
        }catch(DocumentException | IOException e){
            System.out.println(e.toString());
        }
    }
            
            
            
            
            
            
            
            
            
            

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnnuevaventa = new javax.swing.JButton();
        btnventas = new javax.swing.JButton();
        btnproovedor = new javax.swing.JButton();
        btnproductos = new javax.swing.JButton();
        btnconfiguracion = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btncategoria = new javax.swing.JButton();
        lblvendedor = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btneliminarventaprod = new javax.swing.JButton();
        txtcodigoventa = new javax.swing.JTextField();
        txtdescripcionventa = new javax.swing.JTextField();
        txtcantidadventa = new javax.swing.JTextField();
        txtprecioventa = new javax.swing.JTextField();
        txtstockventa = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableventa = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        btnregistrarventa = new javax.swing.JButton();
        lbltotal = new javax.swing.JLabel();
        cmbmodopago = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        lblvuelto = new javax.swing.JLabel();
        txtefectivo = new javax.swing.JTextField();
        lbl = new javax.swing.JLabel();
        panelventas = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tableregistroventa = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        txtidventa = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblcategoria = new javax.swing.JTable();
        txtnombrecategoria = new javax.swing.JTextField();
        btnguardarcategoria = new javax.swing.JButton();
        btneliminarcategoria = new javax.swing.JButton();
        btnactualizarcategoria = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtnombreproovedor = new javax.swing.JTextField();
        txtrutproovedor = new javax.swing.JTextField();
        txtempresaproovedor = new javax.swing.JTextField();
        txtnumeroproveedor = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableproovedores = new javax.swing.JTable();
        btnguardarproovedor = new javax.swing.JButton();
        btneliminarproovedor = new javax.swing.JButton();
        btnactualizarproovedor = new javax.swing.JButton();
        btnlimpiarproovedor = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtcodarticulo = new javax.swing.JTextField();
        txtnombreproducto = new javax.swing.JTextField();
        txtprecioventaproducto = new javax.swing.JTextField();
        txtstockproducto = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblproductos = new javax.swing.JTable();
        btnactualizarproducto = new javax.swing.JButton();
        btnguardarproducto = new javax.swing.JButton();
        btnborrarproducto = new javax.swing.JButton();
        btmlimpiarseleccion = new javax.swing.JButton();
        cmbcategorias = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));

        btnnuevaventa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Nventa.png"))); // NOI18N
        btnnuevaventa.setText("Nueva Venta");
        btnnuevaventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnuevaventaActionPerformed(evt);
            }
        });

        btnventas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/compras.png"))); // NOI18N
        btnventas.setText("Ventas");
        btnventas.setMaximumSize(new java.awt.Dimension(97, 23));
        btnventas.setMinimumSize(new java.awt.Dimension(97, 23));
        btnventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnventasActionPerformed(evt);
            }
        });

        btnproovedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/proveedor.png"))); // NOI18N
        btnproovedor.setText("Proovedor");
        btnproovedor.setMaximumSize(new java.awt.Dimension(97, 23));
        btnproovedor.setMinimumSize(new java.awt.Dimension(97, 23));
        btnproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnproovedorActionPerformed(evt);
            }
        });

        btnproductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/producto.png"))); // NOI18N
        btnproductos.setText("Productos");
        btnproductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnproductosActionPerformed(evt);
            }
        });

        btnconfiguracion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/config.png"))); // NOI18N
        btnconfiguracion.setText("Configuracion");
        btnconfiguracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconfiguracionActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/images.jpg"))); // NOI18N

        btncategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/lupa.png"))); // NOI18N
        btncategoria.setText("Categoria");
        btncategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncategoriaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnconfiguracion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnproductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnventas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnnuevaventa, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(btncategoria, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(lblvendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(lblvendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                .addComponent(btnnuevaventa, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnventas, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnproductos, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnconfiguracion, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btncategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 710));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/dondeleito3.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 830, 170));

        jTabbedPane2.setToolTipText("");
        jTabbedPane2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel2.setText("Codigo");

        jLabel3.setText("Descripcion");

        jLabel4.setText("Cantidad");

        jLabel5.setText("Precio");

        jLabel6.setText("Stock Disponible");

        btneliminarventaprod.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btneliminarventaprod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneliminarventaprodActionPerformed(evt);
            }
        });

        txtcodigoventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodigoventaActionPerformed(evt);
            }
        });
        txtcodigoventa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtcodigoventaKeyPressed(evt);
            }
        });

        txtcantidadventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcantidadventaActionPerformed(evt);
            }
        });
        txtcantidadventa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtcantidadventaKeyPressed(evt);
            }
        });

        txtprecioventa.setEditable(false);

        tableventa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Descripcion", "Cantidad", "Precio", "Total"
            }
        ));
        jScrollPane1.setViewportView(tableventa);
        if (tableventa.getColumnModel().getColumnCount() > 0) {
            tableventa.getColumnModel().getColumn(0).setPreferredWidth(30);
            tableventa.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableventa.getColumnModel().getColumn(2).setPreferredWidth(30);
            tableventa.getColumnModel().getColumn(3).setPreferredWidth(30);
            tableventa.getColumnModel().getColumn(4).setPreferredWidth(40);
        }

        jLabel10.setText("Total a Pagar");

        btnregistrarventa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/money.png"))); // NOI18N
        btnregistrarventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregistrarventaActionPerformed(evt);
            }
        });

        lbltotal.setText("__________________________");

        cmbmodopago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo", "Debito", "Credito" }));
        cmbmodopago.setToolTipText("");
        cmbmodopago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbmodopagoActionPerformed(evt);
            }
        });

        jLabel11.setText("Vuelto");

        lblvuelto.setText("__________________________");

        txtefectivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtefectivoKeyPressed(evt);
            }
        });

        lbl.setText("Cantidad Efectivo");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(95, 95, 95)
                                .addComponent(jLabel3))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtcodigoventa, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtdescripcionventa, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtcantidadventa, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtprecioventa, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtstockventa))
                        .addGap(40, 40, 40)
                        .addComponent(btneliminarventaprod)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cmbmodopago, 0, 158, Short.MAX_VALUE)
                            .addComponent(txtefectivo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblvuelto, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44)
                        .addComponent(btnregistrarventa, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(108, 108, 108))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtcodigoventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtdescripcionventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtcantidadventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtprecioventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtstockventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btneliminarventaprod))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(cmbmodopago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(lblvuelto)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtefectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl)))))
                    .addComponent(btnregistrarventa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Nueva Venta", jPanel2);

        tableregistroventa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Venta", "Total Venta", "Fecha"
            }
        ));
        tableregistroventa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableregistroventaMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tableregistroventa);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/pdf.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelventasLayout = new javax.swing.GroupLayout(panelventas);
        panelventas.setLayout(panelventasLayout);
        panelventasLayout.setHorizontalGroup(
            panelventasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelventasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelventasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtidventa, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 153, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
        );
        panelventasLayout.setVerticalGroup(
            panelventasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelventasLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(panelventasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelventasLayout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtidventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Ventas", panelventas);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("Nombre:");

        tblcategoria.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Categoria", "Nombre"
            }
        ));
        jScrollPane4.setViewportView(tblcategoria);
        if (tblcategoria.getColumnModel().getColumnCount() > 0) {
            tblcategoria.getColumnModel().getColumn(0).setPreferredWidth(20);
        }

        btnguardarcategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnguardarcategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarcategoriaActionPerformed(evt);
            }
        });

        btneliminarcategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N

        btnactualizarcategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(txtnombrecategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(btnguardarcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btneliminarcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnactualizarcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(txtnombrecategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnguardarcategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btneliminarcategoria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnactualizarcategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Categoria", jPanel4);

        jPanel5.setForeground(new java.awt.Color(153, 0, 0));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 0, 0));
        jLabel8.setText("Nombre:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 0));
        jLabel9.setText("RUT:");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 0, 0));
        jLabel12.setText("Empresa:");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 0, 0));
        jLabel13.setText("Telefono:");

        txtnombreproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreproovedorActionPerformed(evt);
            }
        });

        tableproovedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RUT", "Telefono", "Nombre", "Empresa"
            }
        ));
        tableproovedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableproovedoresMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableproovedores);
        if (tableproovedores.getColumnModel().getColumnCount() > 0) {
            tableproovedores.getColumnModel().getColumn(0).setPreferredWidth(10);
            tableproovedores.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableproovedores.getColumnModel().getColumn(2).setPreferredWidth(30);
            tableproovedores.getColumnModel().getColumn(3).setPreferredWidth(30);
        }

        btnguardarproovedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnguardarproovedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnguardarproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarproovedorActionPerformed(evt);
            }
        });

        btneliminarproovedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btneliminarproovedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btneliminarproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneliminarproovedorActionPerformed(evt);
            }
        });

        btnactualizarproovedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnactualizarproovedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnactualizarproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizarproovedorActionPerformed(evt);
            }
        });

        btnlimpiarproovedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/borrar.png"))); // NOI18N
        btnlimpiarproovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarproovedorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel13)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel9)
                                        .addComponent(jLabel8))
                                    .addGap(3, 3, 3)))
                            .addComponent(jLabel12))
                        .addGap(70, 70, 70)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtnombreproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                            .addComponent(txtrutproovedor)
                            .addComponent(txtempresaproovedor)
                            .addComponent(txtnumeroproveedor)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnguardarproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btneliminarproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnactualizarproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                            .addComponent(btnlimpiarproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(41, 41, 41)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtnombreproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtrutproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtempresaproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(txtnumeroproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnguardarproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnactualizarproovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btneliminarproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                            .addComponent(btnlimpiarproovedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Proovedor", jPanel5);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(153, 0, 0));
        jLabel19.setText("Nombre:");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(153, 0, 0));
        jLabel20.setText("Codigo Articulo:");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(153, 0, 0));
        jLabel21.setText("Precio Venta:");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(153, 0, 0));
        jLabel22.setText("Stock Actual:");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(153, 0, 0));
        jLabel23.setText("Categoria:");

        txtnombreproducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreproductoActionPerformed(evt);
            }
        });

        tblproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Categoria", "Nombre Articulo", "Precio Venta", "Stock Actual"
            }
        ));
        tblproductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblproductosMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblproductos);
        if (tblproductos.getColumnModel().getColumnCount() > 0) {
            tblproductos.getColumnModel().getColumn(0).setPreferredWidth(100);
            tblproductos.getColumnModel().getColumn(1).setPreferredWidth(100);
            tblproductos.getColumnModel().getColumn(2).setPreferredWidth(100);
            tblproductos.getColumnModel().getColumn(3).setPreferredWidth(100);
            tblproductos.getColumnModel().getColumn(4).setPreferredWidth(100);
        }

        btnactualizarproducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnactualizarproducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizarproductoActionPerformed(evt);
            }
        });

        btnguardarproducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnguardarproducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarproductoActionPerformed(evt);
            }
        });

        btnborrarproducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnborrarproducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnborrarproductoActionPerformed(evt);
            }
        });

        btmlimpiarseleccion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/borrar.png"))); // NOI18N
        btmlimpiarseleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmlimpiarseleccionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel19))
                                .addGap(11, 11, 11))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel21)
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel23)
                                        .addComponent(jLabel22)))
                                .addGap(32, 32, 32)))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtnombreproducto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                            .addComponent(txtcodarticulo, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtstockproducto)
                            .addComponent(txtprecioventaproducto)
                            .addComponent(cmbcategorias, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(btnguardarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnactualizarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(btnborrarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(55, 55, 55)
                                .addComponent(btmlimpiarseleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(41, 41, 41)))
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 619, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(txtcodarticulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(txtnombreproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(txtprecioventaproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(txtstockproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jLabel23))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(cmbcategorias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(44, 44, 44)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnguardarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnactualizarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btmlimpiarseleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnborrarproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Productos", jPanel6);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 830, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnproovedorActionPerformed
        LimpiarTable();
        ListarProovedores();
        jTabbedPane2.setSelectedIndex(3);
    }//GEN-LAST:event_btnproovedorActionPerformed

    private void btncategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncategoriaActionPerformed
        ListarCategoria();
        jTabbedPane2.setSelectedIndex(2);        
    }//GEN-LAST:event_btncategoriaActionPerformed

    private void btnproductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnproductosActionPerformed

        LimpiarTable();
        ListarProductos();
        jTabbedPane2.setSelectedIndex(4);
        
    }//GEN-LAST:event_btnproductosActionPerformed
    
    private boolean esNumerico(String texto) {
        try {
            Integer.parseInt(texto);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    private void btnnuevaventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnuevaventaActionPerformed
        jTabbedPane2.setSelectedIndex(0);           // TODO add your handling code here:
    }//GEN-LAST:event_btnnuevaventaActionPerformed

    private void btnventasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnventasActionPerformed
        jTabbedPane2.setSelectedIndex(1);
        LimpiarTable();
        ListarVentas();        // TODO add your handling code here:
    }//GEN-LAST:event_btnventasActionPerformed

    private void btnconfiguracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconfiguracionActionPerformed
        open.setVisible(true);
        this.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_btnconfiguracionActionPerformed

    private void btmlimpiarseleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmlimpiarseleccionActionPerformed

        txtcodarticulo.setText("");
        txtnombreproducto.setText("");
        txtprecioventaproducto.setText("");
        txtstockproducto.setText("");
        cmbcategorias.setSelectedIndex(0);
        txtcodarticulo.setEnabled(true);
    }//GEN-LAST:event_btmlimpiarseleccionActionPerformed

    private void btnborrarproductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnborrarproductoActionPerformed
        if(!"".equals(txtcodarticulo.getText())){
            int pregunta = JOptionPane.showConfirmDialog(null,"Estas seguro de eliminar?");
            if (pregunta == 0){
                int id = Integer.parseInt(txtcodarticulo.getText());
                prod.EliminarProducto(id);
                LimpiarTable();
                ListarProductos();
            }
        }
    }//GEN-LAST:event_btnborrarproductoActionPerformed

    private void btnguardarproductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarproductoActionPerformed
        if (!"".equals(txtcodarticulo.getText()) &&
            !"".equals(txtnombreproducto.getText()) &&
            !"".equals(txtprecioventaproducto.getText()) &&
            !"".equals(txtstockproducto.getText()) &&
            cmbcategorias.getSelectedItem() != null) {

            try {
                // Convertir los valores de los campos
                int codArticulo = Integer.parseInt(txtcodarticulo.getText());
                String nombreProducto = txtnombreproducto.getText();

                // Verificar si el producto ya existe
                boolean existe = prod.ExisteProducto(codArticulo, nombreProducto);

                if (existe) {
                    JOptionPane.showMessageDialog(null, "El código o nombre del producto ya existen.");
                } else {
                    // Si no existe, proceder a guardar el producto
                    pro.setCod_articulo(codArticulo);
                    pro.setNombre_articulo(nombreProducto);
                    pro.setPrecio_venta(Integer.parseInt(txtprecioventaproducto.getText())); // Usar Double.parseDouble si tiene decimales
                    pro.setStock_actual(Integer.parseInt(txtstockproducto.getText()));
                    pro.setCod_categoria(Integer.parseInt(cmbcategorias.getSelectedItem().toString()));

                    // Registrar el producto
                    prod.RegistrarProductos(pro);
                    JOptionPane.showMessageDialog(null, "Producto agregado correctamente.");
                    LimpiarTable();
                    ListarProductos();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error en los datos numéricos. Verifica los campos.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
        }
    }//GEN-LAST:event_btnguardarproductoActionPerformed

    private void btnactualizarproductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarproductoActionPerformed
        if ("".equals(txtcodarticulo.getText())){
            JOptionPane.showMessageDialog(null, "Seleccione una fila");
        }else{
            if(!"".equals(txtnombreproducto.getText()) || !"".equals(txtprecioventaproducto.getText()) || !"".equals(txtstockproducto.getText())){
                pro.setCod_categoria(Integer.parseInt(cmbcategorias.getSelectedItem().toString()));
                pro.setNombre_articulo(txtnombreproducto.getText());
                pro.setPrecio_venta(Integer.parseInt(txtprecioventaproducto.getText()));
                pro.setStock_actual(Integer.parseInt(txtstockproducto.getText()));
                pro.setCod_articulo(Integer.parseInt(txtcodarticulo.getText()));
                prod.ModificarProducto(pro);
                JOptionPane.showMessageDialog(null, "Producto Modificado");
                LimpiarTable();
                ListarProductos();
            }

        }
    }//GEN-LAST:event_btnactualizarproductoActionPerformed

    private void tblproductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblproductosMouseClicked
        int fila = tblproductos.rowAtPoint(evt.getPoint());
        txtcodarticulo.setText(tblproductos.getValueAt(fila, 0).toString());
        cmbcategorias.setSelectedItem(tblproductos.getValueAt(fila, 1).toString());
        txtnombreproducto.setText(tblproductos.getValueAt(fila, 2).toString());
        txtprecioventaproducto.setText(tblproductos.getValueAt(fila, 3).toString());
        txtstockproducto.setText(tblproductos.getValueAt(fila, 4).toString());
        txtcodarticulo.setEnabled(false);
    }//GEN-LAST:event_tblproductosMouseClicked

    private void txtnombreproductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreproductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreproductoActionPerformed

    private void btnlimpiarproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarproovedorActionPerformed
        txtnombreproovedor.setText("");
        txtrutproovedor.setText("");
        txtnumeroproveedor.setText("");
        txtempresaproovedor.setText("");
        txtrutproovedor.setEnabled(true);
    }//GEN-LAST:event_btnlimpiarproovedorActionPerformed

    private void btnactualizarproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarproovedorActionPerformed
        if ("".equals(txtrutproovedor.getText())){
            JOptionPane.showMessageDialog(null, "Seleccione una fila");
        }else{
            if(!"".equals(txtnombreproovedor.getText()) || !"".equals(txtrutproovedor.getText()) || !"".equals(txtnumeroproveedor.getText()) || !"".equals(txtempresaproovedor.getText()) ){
                prov.setRut_proovedor(txtrutproovedor.getText());
                prov.setTelefono(Integer.parseInt(txtnumeroproveedor.getText()));
                prov.setNombre(txtnombreproovedor.getText());
                prov.setEmpresa(txtempresaproovedor.getText());
                provdao.ModificarProveedor(prov);
                JOptionPane.showMessageDialog(null, "Producto Modificado");
                LimpiarTable();
                ListarProovedores();
            }

        }        // TODO add your handling code here:
    }//GEN-LAST:event_btnactualizarproovedorActionPerformed

    private void btneliminarproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneliminarproovedorActionPerformed
        if(!"".equals(txtrutproovedor.getText())){
            int pregunta = JOptionPane.showConfirmDialog(null,"Estas seguro de eliminar?");
            if (pregunta == 0){
                String rut = txtrutproovedor.getText();
                provdao.EliminarProovedor(rut);
                LimpiarTable();
                ListarProovedores();
            }
        }
    }//GEN-LAST:event_btneliminarproovedorActionPerformed

    private void btnguardarproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarproovedorActionPerformed
        if (!"".equals(txtnombreproovedor.getText()) &&
            !"".equals(txtrutproovedor.getText()) &&
            !"".equals(txtempresaproovedor.getText()) &&
            !"".equals(txtnumeroproveedor.getText())){

            try {
                // Convertir los valores de los campos
                String rut = txtrutproovedor.getText();

                // Verificar si el producto ya existe
                boolean existe = provdao.ExisteProovedor(rut);

                if (existe) {
                    JOptionPane.showMessageDialog(null, "El rut o nombre de proovedor ya existen.");
                } else {
                    // Si no existe, proceder a guardar el producto
                    prov.setRut_proovedor(rut);
                    prov.setTelefono(Integer.parseInt(txtnumeroproveedor.getText())); // Usar Double.parseDouble si tiene decimales
                    prov.setNombre(txtnombreproovedor.getText());
                    prov.setEmpresa(txtempresaproovedor.getText());

                    // Registrar el producto
                    provdao.RegistrarProovedor(prov);
                    JOptionPane.showMessageDialog(null, "Producto agregado correctamente.");
                    LimpiarTable();
                    ListarProovedores();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error en los datos numéricos. Verifica los campos.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
        }
    }//GEN-LAST:event_btnguardarproovedorActionPerformed

    private void tableproovedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableproovedoresMouseClicked
        int fila = tableproovedores.rowAtPoint(evt.getPoint());
        txtnombreproovedor.setText(tableproovedores.getValueAt(fila, 2).toString());
        txtrutproovedor.setText(tableproovedores.getValueAt(fila, 0).toString());
        txtnumeroproveedor.setText(tableproovedores.getValueAt(fila, 1).toString());
        txtempresaproovedor.setText(tableproovedores.getValueAt(fila, 3).toString());
        txtrutproovedor.setEnabled(false);
    }//GEN-LAST:event_tableproovedoresMouseClicked

    private void txtnombreproovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreproovedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreproovedorActionPerformed

    private void btnguardarcategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarcategoriaActionPerformed
        if (!"".equals(txtnombrecategoria.getText())){
            cat.setNombre(txtnombrecategoria.getText());
            try {
                catd.RegistrarCategoria(cat);
                JOptionPane.showMessageDialog(null, "Categoría agregada correctamente");
            }catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al guardar la categoría");
            }
        }else{
            JOptionPane.showMessageDialog(null,"Los campos estan vacios");
        }
    }//GEN-LAST:event_btnguardarcategoriaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try{
            int id = Integer.parseInt(txtidventa.getText());
            File file = new File("src/pdf/venta_"+id+".pdf");
            Desktop.getDesktop().open(file);
        }catch(IOException ex){

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tableregistroventaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableregistroventaMouseClicked
        int fila = tableregistroventa.rowAtPoint(evt.getPoint());
        txtidventa.setText(tableregistroventa.getValueAt(fila, 0).toString());
    }//GEN-LAST:event_tableregistroventaMouseClicked

    private void txtefectivoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtefectivoKeyPressed
        Vuelto();
        // TODO add your handling code here:
    }//GEN-LAST:event_txtefectivoKeyPressed

    private void cmbmodopagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbmodopagoActionPerformed
        int indice = cmbmodopago.getSelectedIndex();
        if (indice == 0){
            txtefectivo.setVisible(false);
            lbl.setVisible(true);
        }else{
            txtefectivo.setVisible(false);
            lbl.setVisible(false);
        }       // TODO add your handling code here:
    }//GEN-LAST:event_cmbmodopagoActionPerformed

    private void btnregistrarventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregistrarventaActionPerformed
        int flag = cmbmodopago.getSelectedIndex();
        String efectivoTexto = txtefectivo.getText().trim();
        if (flag == 0 && (efectivoTexto.isEmpty() || !esNumerico(efectivoTexto))) {
            System.out.println("Ingrese una cantidad válida de efectivo.");
        } else {
            RegistrarVenta();
            RegistrarDetalleVenta();
            ActualizarStock();
            pdf();
            LimpiarTableVenta();
            lbltotal.setText("");
            lblvuelto.setText("");
        }
    }//GEN-LAST:event_btnregistrarventaActionPerformed

    private void txtcantidadventaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcantidadventaKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            if(!"".equals(txtcantidadventa.getText())){
                String cod = txtcodigoventa.getText();
                String descripcion = txtdescripcionventa.getText();
                int cant = Integer.parseInt(txtcantidadventa.getText());
                int precio = Integer.parseInt(txtprecioventa.getText());
                int total = cant * precio;
                int stock = Integer.parseInt(txtstockventa.getText());
                if (stock >= cant){
                    item = item + 1;
                    DefaultTableModel tmp =(DefaultTableModel) tableventa.getModel();
                    for(int i = 0; i < tableventa.getRowCount(); i++){
                        if(tableventa.getValueAt(i, 1).equals(txtdescripcionventa.getText())){
                            JOptionPane.showMessageDialog(null, "El producto ya esta registrado");
                            return;
                        }
                    }
                    ArrayList lista = new ArrayList();
                    lista.add(item);
                    lista.add(cod);
                    lista.add(descripcion);
                    lista.add(cant);
                    lista.add(precio);
                    lista.add(total);
                    Object[] O = new Object[5];
                    O[0] = lista.get(1);
                    O[1] = lista.get(2);
                    O[2] = lista.get(3);
                    O[3] = lista.get(4);
                    O[4] = lista.get(5);
                    tmp.addRow(O);
                    tableventa.setModel(tmp);
                    TotalPagar();
                    LimpiarVenta();
                    txtcodigoventa.requestFocus();
                }else{
                    JOptionPane.showMessageDialog(null, "Stock no disponible");
                }

            }else{
                JOptionPane.showMessageDialog(null, "Ingrese Cantidad");
            }
        }
    }//GEN-LAST:event_txtcantidadventaKeyPressed

    private void txtcantidadventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcantidadventaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcantidadventaActionPerformed

    private void txtcodigoventaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcodigoventaKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            if (!"".equals(txtcodigoventa.getText())){
                String cod = txtcodigoventa.getText();
                pro = prod.BuscarPro(cod);
                if(rootPaneCheckingEnabled){
                    if(pro.getNombre_articulo() != null){
                        txtdescripcionventa.setText(""+pro.getNombre_articulo());
                        txtprecioventa.setText(""+pro.getPrecio_venta());
                        txtstockventa.setText(""+pro.getStock_actual());
                        txtcantidadventa.requestFocus();
                    }else{
                        LimpiarVenta();
                        txtcodigoventa.requestFocus();
                    }
                }
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese el codigo del producto");
                txtcodigoventa.requestFocus();
            }
        }
    }//GEN-LAST:event_txtcodigoventaKeyPressed

    private void txtcodigoventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodigoventaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodigoventaActionPerformed

    private void btneliminarventaprodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneliminarventaprodActionPerformed
        modelo = (DefaultTableModel) tableventa.getModel();
        modelo.removeRow(tableventa.getSelectedRow());
        TotalPagar();
        txtcodigoventa.requestFocus();
    }//GEN-LAST:event_btneliminarventaprodActionPerformed


    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sistema().setVisible(true);
            }
        });
    }
    
   
            
            
            
            
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmlimpiarseleccion;
    private javax.swing.JButton btnactualizarcategoria;
    private javax.swing.JButton btnactualizarproducto;
    private javax.swing.JButton btnactualizarproovedor;
    private javax.swing.JButton btnborrarproducto;
    private javax.swing.JButton btncategoria;
    private javax.swing.JButton btnconfiguracion;
    private javax.swing.JButton btneliminarcategoria;
    private javax.swing.JButton btneliminarproovedor;
    private javax.swing.JButton btneliminarventaprod;
    private javax.swing.JButton btnguardarcategoria;
    private javax.swing.JButton btnguardarproducto;
    private javax.swing.JButton btnguardarproovedor;
    private javax.swing.JButton btnlimpiarproovedor;
    private javax.swing.JButton btnnuevaventa;
    private javax.swing.JButton btnproductos;
    private javax.swing.JButton btnproovedor;
    private javax.swing.JButton btnregistrarventa;
    private javax.swing.JButton btnventas;
    private javax.swing.JComboBox<String> cmbcategorias;
    private javax.swing.JComboBox<String> cmbmodopago;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lbltotal;
    private javax.swing.JLabel lblvendedor;
    private javax.swing.JLabel lblvuelto;
    private javax.swing.JPanel panelventas;
    private javax.swing.JTable tableproovedores;
    private javax.swing.JTable tableregistroventa;
    private javax.swing.JTable tableventa;
    private javax.swing.JTable tblcategoria;
    private javax.swing.JTable tblproductos;
    private javax.swing.JTextField txtcantidadventa;
    private javax.swing.JTextField txtcodarticulo;
    private javax.swing.JTextField txtcodigoventa;
    private javax.swing.JTextField txtdescripcionventa;
    private javax.swing.JTextField txtefectivo;
    private javax.swing.JTextField txtempresaproovedor;
    private javax.swing.JTextField txtidventa;
    private javax.swing.JTextField txtnombrecategoria;
    private javax.swing.JTextField txtnombreproducto;
    private javax.swing.JTextField txtnombreproovedor;
    private javax.swing.JTextField txtnumeroproveedor;
    private javax.swing.JTextField txtprecioventa;
    private javax.swing.JTextField txtprecioventaproducto;
    private javax.swing.JTextField txtrutproovedor;
    private javax.swing.JTextField txtstockproducto;
    private javax.swing.JTextField txtstockventa;
    // End of variables declaration//GEN-END:variables
}
