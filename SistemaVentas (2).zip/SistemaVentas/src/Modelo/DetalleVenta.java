/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ignam
 */
public class DetalleVenta {
    private int id_venta;
    private int cod_articulo;
    private int cantidad;
    private int precio_unitario_venta;
    
    public DetalleVenta(){
    
    }

    public DetalleVenta(int id_venta, int cod_articulo, int cantidad, int precio_unitario_venta) {
        this.id_venta = id_venta;
        this.cod_articulo = cod_articulo;
        this.cantidad = cantidad;
        this.precio_unitario_venta = precio_unitario_venta;
    }

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }

    public int getCod_articulo() {
        return cod_articulo;
    }

    public void setCod_articulo(int cod_articulo) {
        this.cod_articulo = cod_articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio_unitario_venta() {
        return precio_unitario_venta;
    }

    public void setPrecio_unitario_venta(int precio_unitario_venta) {
        this.precio_unitario_venta = precio_unitario_venta;
    }
    
    
}
