/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ignam
 */
public class DetalleCompra {
    
    private int id_compra;
    private String cod_articulo;
    private int cantidad;
    private int precio_unitario;
    
    public DetalleCompra(){

    }

    public DetalleCompra(int id_compra, String cod_articulo, int cantidad, int precio_unitario) {
        this.id_compra = id_compra;
        this.cod_articulo = cod_articulo;
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public String getCod_articulo() {
        return cod_articulo;
    }

    public void setCod_articulo(String cod_articulo) {
        this.cod_articulo = cod_articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio_unitario() {
        return precio_unitario;
    }

    public void setPrecio_unitario(int precio_unitario) {
        this.precio_unitario = precio_unitario;
    }
    
    
}
