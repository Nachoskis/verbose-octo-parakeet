/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import java.sql.ResultSet;
/**
 *
 * @author ignam
 */
public class ProductosDAO {
    
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean RegistrarProductos(Productos pro){
        String sql = "INSERT INTO articulo (cod_articulo,cod_categoria,nombre_articulo,precio_venta,stock_actual) VALUES (?,?,?,?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, pro.getCod_articulo());
            ps.setInt(2, pro.getCod_categoria());
            ps.setString(3, pro.getNombre_articulo());
            ps.setInt(4, pro.getPrecio_venta());
            ps.setInt(5, pro.getStock_actual());
            ps.execute();
            return true;
        }catch (SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public void LlenarCategoria(JComboBox proovedor){
        String sql = "SELECT cod_categoria FROM categoria";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                proovedor.addItem(rs.getString("cod_categoria"));               
            }
            
        }catch (SQLException e){
            System.out.println(e.toString());
        }
        
    }
    
    public List ListarProductos(){
        List<Productos> Listarpro = new ArrayList();
        String sql = "SELECT * FROM articulo";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Productos pro = new Productos();
                pro.setCod_articulo(rs.getInt("cod_articulo"));
                pro.setCod_categoria(rs.getInt("cod_categoria"));
                pro.setNombre_articulo(rs.getString("nombre_articulo"));
                pro.setPrecio_venta(rs.getInt("precio_venta"));
                pro.setStock_actual(rs.getInt("stock_actual"));
                Listarpro.add(pro);
            }
        }catch (SQLException e) {
            System.out.println(e.toString());
        }
        return Listarpro;
    }
    
    public boolean EliminarProducto(int codigo_producto){
        String sql = "DELETE FROM articulo WHERE cod_articulo = ?";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, codigo_producto);
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }finally{
            try{
                con.close();
            }catch (SQLException ex){
                System.out.println(ex.toString());
            }
           
        }
    }

    public boolean ModificarProducto(Productos pr){
        String sql = "UPDATE articulo SET cod_categoria=?, nombre_articulo=?, precio_venta=?,stock_actual=? WHERE cod_articulo=?";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, pr.getCod_categoria());
            ps.setString(2, pr.getNombre_articulo());
            ps.setInt(3, pr.getPrecio_venta());
            ps.setInt(4, pr.getStock_actual());
            ps.setInt(5, pr.getCod_articulo());
            ps.execute();
            return true;
        }catch (SQLException e){
            System.out.println(e.toString());
            return false;    
        }
           
        
        
    }
    
    public boolean ExisteProducto(int cod_articulo, String nombre_articulo) {
    String sql = "SELECT COUNT(*) FROM articulo WHERE cod_articulo = ? OR nombre_articulo = ?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, cod_articulo); // Verifica el código del artículo
        ps.setString(2, nombre_articulo); // Verifica el nombre del artículo
        rs = ps.executeQuery();

        // Si hay al menos un resultado, entonces el producto ya existe
        if (rs.next() && rs.getInt(1) > 0) {
            return true; // El producto ya existe
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    } finally {
        try {
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    return false; // El producto no existe
}
    
    public boolean ExisteNombreProductoParaActualizar(String nombre_articulo, int cod_articulo) {
    String sql = "SELECT COUNT(*) FROM articulo WHERE nombre_articulo = ? AND cod_articulo != ?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, nombre_articulo); // Verificar el nombre del producto
        ps.setInt(2, cod_articulo); // Excluir el producto actual
        rs = ps.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            return true; // El nombre ya existe en otro producto
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    } finally {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    return false; // El nombre no existe en otro producto
}
    
    public Productos BuscarPro(String cod){
        Productos producto = new Productos();
        String sql = "Select * FROM articulo WHERE cod_articulo = ?";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, cod);
            rs = ps.executeQuery();
            if(rs.next()){
                producto.setNombre_articulo(rs.getString("nombre_articulo"));
                producto.setPrecio_venta(rs.getInt("precio_venta"));
                producto.setStock_actual(rs.getInt("stock_Actual"));
            }
        }catch (Exception e){
            System.out.println(e.toString());
        }
        return producto;
    }
}
