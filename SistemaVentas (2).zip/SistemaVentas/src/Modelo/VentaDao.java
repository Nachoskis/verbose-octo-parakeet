/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class VentaDao {
    
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public int IdVenta(){
        int id = 0;
        String sql = "SELECT MAX(id_venta) from venta";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()){
                id = rs.getInt(1);
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return id;
    }
    
    public int RegistrarVenta(Ventas v){        
        String sql = "INSERT INTO venta(valor_total, fecha) VALUES (?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, v.getValor_total());
            ps.setDate(2, new java.sql.Date(v.getFecha().getTime()));
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.toString());
        }finally{
            try{
                con.close();
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public int RegistrarDetalleVenta(DetalleVenta Dv){
        String sql = "INSERT INTO detalle_venta (id_venta,cod_articulo,cantidad,precio_unitario_venta) VALUES (?,?,?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, Dv.getId_venta());
            ps.setInt(2, Dv.getCod_articulo());
            ps.setInt(3, Dv.getCantidad());
            ps.setInt(4, Dv.getPrecio_unitario_venta());
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.toString());
        }finally{
            try{
                con.close();
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public boolean ActualizarStock(int cant, String cod){
        String sql = "UPDATE articulo SET stock_actual = ? WHERE cod_articulo = ?";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, cant);
            ps.setString(2, cod);
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public List ListarVentas(){
        List<Ventas> ListaVenta = new ArrayList();
        String sql = "SELECT * FROM venta";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Ventas vent = new Ventas();
                vent.setId_venta(rs.getInt("id_venta"));
                vent.setValor_total(rs.getInt("valor_total"));
                vent.setFecha(rs.getDate("fecha"));
                ListaVenta.add(vent);
            }
        }catch (SQLException e) {
            System.out.println(e.toString());
        }
        return ListaVenta;
    }
}
