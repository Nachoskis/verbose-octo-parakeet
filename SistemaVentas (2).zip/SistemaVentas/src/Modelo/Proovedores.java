/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ignam
 */
public class Proovedores {
    String rut_proovedor;
    int telefono;
    String nombre;
    String empresa;
    
    public Proovedores(){
    
    }

    public Proovedores(String rut_proovedor, int telefono, String nombre, String empresa) {
        this.rut_proovedor = rut_proovedor;
        this.telefono = telefono;
        this.nombre = nombre;
        this.empresa = empresa;
    }

    public String getRut_proovedor() {
        return rut_proovedor;
    }

    public void setRut_proovedor(String rut_proovedor) {
        this.rut_proovedor = rut_proovedor;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
    
    
}
