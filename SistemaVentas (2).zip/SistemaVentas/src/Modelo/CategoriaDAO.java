
package Modelo;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;


public class CategoriaDAO {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean RegistrarCategoria(Categoria ct){
        String sql = "INSERT INTO categoria(nombre) VALUES (?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, ct.getNombre());
            ps.execute();
            return true;
        }catch (SQLException e){
            System.out.println(e.toString());
            return false;
        }finally{
            try{
                con.close();
            }catch (SQLException e){
                System.out.println(e.toString());
            }
        }
    }
    
    public List ListarCategoria(){
        List<Categoria> Listarcat = new ArrayList();
        String sql = "SELECT * FROM categoria";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Categoria ct = new Categoria();
                ct.setCategoria(rs.getInt("cod_categoria"));
                ct.setNombre(rs.getString("nombre"));
                Listarcat.add(ct);
            }
        }catch (SQLException e) {
            System.out.println(e.toString());
        }
        return Listarcat;
    }
}
