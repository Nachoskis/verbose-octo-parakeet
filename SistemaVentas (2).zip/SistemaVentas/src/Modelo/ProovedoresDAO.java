/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ignam
 */
public class ProovedoresDAO {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean RegistrarProovedor(Proovedores prov){
        String sql = "INSERT INTO proveedor (rut_proveedor,telefono,nombre,empresa) VALUES (?,?,?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, prov.getRut_proovedor());
            ps.setInt(2, prov.getTelefono());
            ps.setString(3, prov.getNombre());
            ps.setString(4, prov.getEmpresa());
            ps.execute();
            return true;
        }catch (SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public List ListarProovedores(){
        List<Proovedores> Listarprov = new ArrayList();
        String sql = "SELECT * FROM proveedor";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Proovedores prov = new Proovedores();
                prov.setRut_proovedor(rs.getString("rut_proveedor"));
                prov.setTelefono(rs.getInt("telefono"));
                prov.setNombre(rs.getString("nombre"));
                prov.setEmpresa(rs.getString("empresa"));
                Listarprov.add(prov);
            }
        }catch (SQLException e) {
            System.out.println(e.toString());
        }
        return Listarprov;
    }
    
    public boolean EliminarProovedor(String rut_proovedor){
        String sql = "DELETE FROM proveedor WHERE rut_proveedor = ?";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, rut_proovedor);
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }finally{
            try{
                con.close();
            }catch (SQLException ex){
                System.out.println(ex.toString());
            }
           
        }
    }
    
    public boolean ModificarProveedor(Proovedores prov){
        String sql = "UPDATE proveedor SET  telefono=?, nombre=?,empresa=? WHERE rut_proveedor=?";
        try{
            ps = con.prepareStatement(sql);
            ps.setInt(1, prov.getTelefono());
            ps.setString(2, prov.getNombre());
            ps.setString(3, prov.getEmpresa());
            ps.setString(4, prov.getRut_proovedor());
            ps.execute();
            return true;
        }catch (SQLException e){
            System.out.println(e.toString());
            return false;    
        }                           
    }
    
    public boolean ExisteProovedor(String rut) {
    String sql = "SELECT COUNT(*) FROM proveedor WHERE rut_proveedor = ?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, rut); // Verifica el rut del proovedor
        rs = ps.executeQuery();
        

        // Si hay al menos un resultado, entonces el producto ya existe
        if (rs.next() && rs.getInt(1) > 0) {
            return true; // El producto ya existe
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    } finally {
        try {
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    return false; // El producto no existe
}
    
    
}
