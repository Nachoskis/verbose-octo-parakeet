
package Modelo;


public class Productos {
    private int  cod_articulo;
    private int cod_categoria;
    private String nombre_articulo;
    private int precio_venta;
    private int stock_actual;
    
    public Productos(){
        
    }

    public Productos(int cod_articulo, int cod_categoria, String nombre_articulo, int precio_venta, int stock) {
        this.cod_articulo = cod_articulo;
        this.cod_categoria = cod_categoria;
        this.nombre_articulo = nombre_articulo;
        this.precio_venta = precio_venta;
        this.stock_actual = stock;
    }

    public int getCod_articulo() {
        return cod_articulo;
    }

    public void setCod_articulo(int cod_articulo) {
        this.cod_articulo = cod_articulo;
    }

    public int getCod_categoria() {
        return cod_categoria;
    }

    public void setCod_categoria(int cod_categoria) {
        this.cod_categoria = cod_categoria;
    }

    public String getNombre_articulo() {
        return nombre_articulo;
    }

    public void setNombre_articulo(String nombre_articulo) {
        this.nombre_articulo = nombre_articulo;
    }

    public int getPrecio_venta() {
        return precio_venta;
    }

    public void setPrecio_venta(int precio_venta) {
        this.precio_venta = precio_venta;
    }

    public int getStock_actual() {
        return stock_actual;
    }

    public void setStock_actual(int stock_actual) {
        this.stock_actual = stock_actual;
    }

       
}
