/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author ignam
 */
public class Compra {
    private int id_compra;
    private String rut_vendedor;
    private Date fecha;
    private int precio_total;
    
    public Compra(){
    
    }

    public Compra(int id_compra, String rut_vendedor, Date fecha, int precio_total) {
        this.id_compra = id_compra;
        this.rut_vendedor = rut_vendedor;
        this.fecha = fecha;
        this.precio_total = precio_total;
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public String getRut_vendedor() {
        return rut_vendedor;
    }

    public void setRut_vendedor(String rut_vendedor) {
        this.rut_vendedor = rut_vendedor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getPrecio_total() {
        return precio_total;
    }

    public void setPrecio_total(int precio_total) {
        this.precio_total = precio_total;
    }
    
    
}
