/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ignam
 */
public class CompraDAO {
   
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public int IdCompra(){
        int id = 0;
        String sql = "SELECT MAX(id_compra) from compra";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()){
                id = rs.getInt(1);
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return id;
    }
    
    public int RegistrarCompra(Compra c){        
        String sql = "INSERT INTO compra(rut_ventedor, fecha,  precio_total) VALUES (?,?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getRut_vendedor());
            ps.setDate(2, new java.sql.Date(c.getFecha().getTime()));
            ps.setInt(3, c.getPrecio_total());
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.toString());
        }finally{
            try{
                con.close();
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public int RegistrarDetalleCompra(DetalleCompra Dc){
        String sql = "INSERT INTO detalle_compra (id_compra,cod_articulo,cantidad,precio_unitario) VALUES (?,?,?,?)";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, Dc.getId_compra());
            ps.setString(2, Dc.getCod_articulo());
            ps.setInt(3, Dc.getCantidad());
            ps.setInt(4, Dc.getPrecio_unitario());
            ps.execute();
        }catch(SQLException e){
            System.out.println(e.toString());
        }finally{
            try{
                con.close();
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public List ListarCompras(){
        List<Compra> ListaCompra = new ArrayList();
        String sql = "SELECT * FROM compra";
        try{
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Compra comp = new Compra();
                comp.setId_compra(rs.getInt("id_compra"));
                comp.setRut_vendedor(rs.getString("rut_vendedor"));
                comp.setFecha(rs.getDate("fecha"));
                comp.setPrecio_total(rs.getInt("precio_total"));
                ListaCompra.add(comp);
            }
        }catch (SQLException e) {
            System.out.println(e.toString());
        }
        return ListaCompra;
    }
    
    
    
}
